package w2_13_advancedsimulator;

public class SatelTV implements TV {
    private boolean isOn;
    private int channel;
    private int volume;
    private int light;
    private int contrast;

    public SatelTV(int channel, int volume, int light, int contrast) {
        this.channel = channel;
        this.volume = volume;
        this.light = light;
        this.contrast = contrast;
        isOn = false;
    }

    public int getChannel() {
        return channel;
    }
    public int getVolume() {
        return volume;
    }
    public int getLight() {
        return light;
    }
    public int getContrast() {
        return contrast;
    }

    @Override
    public void powerToggle() {
        if(this.isOn){
            this.isOn = false;
            System.out.println("off");
            return;
        }
        this.isOn = true;
        System.out.println("on");
    };

    @Override
    public void channelUp(){
        if(!this.isOn){
            return;
        }
        this.channel++;
        System.out.println("channel up"+this.channel);
    }

    @Override
    public void channelDown(){
        if(!this.isOn){
            return;}
        this.channel--;
        System.out.println("channel down"+this.channel);
    }
    @Override
    public void lightUp(){
        if(!this.isOn){
            return;
        }
        this.light++;
        System.out.println("light up"+this.light);
    }
    @Override
    public void lightDown(){
        if(!this.isOn){
            return;
        }
        this.light--;
        System.out.println("light down"+this.light);
    }
    @Override
    public void contrastUp(){
        if(!this.isOn){
            return;
        }
        this.contrast++;
        System.out.println("contrast up"+this.contrast);
    }
    @Override
    public void contrastDown(){
        if(!this.isOn){
            return;
        }
        this.contrast--;
        System.out.println("contrast down"+this.contrast);
    }

    @Override
    public void volumeUp(){
        if(!this.isOn){
            return;
        }
        this.volume++;
        System.out.println("volume up"+this.volume);
    }
    @Override
    public void volumeDown(){
        if(!this.isOn){
            return;
        }
        this.volume--;
        System.out.println("volume down"+this.volume);
    }
}
