package w2_13_advancedsimulator;

public interface TV {
    void powerToggle();

    void channelUp();

    void channelDown();

    void lightUp();

    void lightDown();

    void contrastUp();

    void contrastDown();

    void volumeUp();

    void volumeDown();
}
