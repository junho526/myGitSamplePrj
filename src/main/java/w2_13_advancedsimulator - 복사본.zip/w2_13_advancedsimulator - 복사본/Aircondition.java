package w2_13_advancedsimulator;

public class Aircondition implements Aircon {
    private boolean isOn;
    private int speed;
    private int degree;
    private int vector;

    public Aircondition(int speed, int degree, int vector) {
        isOn = false;
        this.speed = speed;
        this.degree = degree;
        this.vector = vector;
    }

    @Override
    public void powerToggle() {
        if(this.isOn){
            this.isOn = false;
            System.out.println("off");
            return;
        }
        this.isOn = true;
        System.out.println("on");

    }

    public void speedUp() {
        if(!this.isOn){
            return;
        }
        this.speed++;
        System.out.println("speed up " + this.speed);
    }

    @Override
    public void speedDown() {
        if (!this.isOn){
            return;
        }
        this.speed--;
        System.out.println("speed down " + this.speed);
    }

    @Override
    public void degreeUp() {
        if(!this.isOn){
            return;
        }
        this.degree++;
        System.out.println("degree up " + this.degree);
    }

    @Override
    public void degreeDown() {
        if(!this.isOn){
            return;
        }
        this.degree--;
        System.out.println("degree down " + this.degree);
    }

    @Override
    public void vectorUp() {
        if (!this.isOn){
            return;
        }
        this.vector++;
        System.out.println("vector up " + this.vector);
    }


    @Override
    public void vectorDown() {
        if (!this.isOn){
            return;
        }
        this.vector--;
        System.out.println("vector down " + this.vector);
    }


}
