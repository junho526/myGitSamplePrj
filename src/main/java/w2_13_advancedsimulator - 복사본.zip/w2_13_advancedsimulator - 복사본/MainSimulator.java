package w2_13_advancedsimulator;

import java.util.Scanner;

public class MainSimulator {
    public static void main(String[] args) {
        TV mySatelTV = new SatelTV(12, 20, 55, 55);
        TV myInterTV = new InterTV(11, 10, 50, 50);
        Aircon myAircon = new Aircondition(10, 21, 10);

        MultiRemocon myMultiRc = new MultiRemocon();
        Scanner myScanner = new Scanner(System.in);
        Object selectMode = null;

        while (selectMode == null) {
            System.out.println("위성 TV: 1, 인터넷 TV: 2, 에어컨 모드: 3");
            System.out.print("모드를 선택하세요: ");
            String consoleInput = myScanner.nextLine();

            switch (consoleInput) {
                case "1":
                    selectMode = mySatelTV;
                    System.out.println("위성 TV를 선택하셨습니다.");
                    break;
                case "2":
                    selectMode = myInterTV;
                    System.out.println("인터넷 TV를 선택하셨습니다.");
                    break;
                case "3":
                    selectMode = myAircon;
                    System.out.println("에어컨 모드를 선택하셨습니다.");
                    break;
                default:
                    System.out.println("잘못된 입력입니다. 다시 시도하세요.");
            }
        }

        // 메인 동작 루프
        while (true) {
            printButtonSpec(selectMode); // 버튼 명세 출력

            System.out.print("명령어를 입력하시오: ");
            String btnInput = myScanner.nextLine();

            // 종료 조건
            if (btnInput.equals("exit")) {
                System.out.println("프로그램을 종료합니다.");
                break;
            }

            // 버튼 입력 처리
            if (selectMode instanceof TV) {
                myMultiRc.btnPress((TV) selectMode, btnInput);
            } else if (selectMode instanceof Aircon) {
                myMultiRc.btnPress((Aircon) selectMode, btnInput);
            } else {
                System.out.println("알 수 없는 기기입니다.");
            }

            // 대기
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.err.println("실행 중 오류 발생: " + e.getMessage());
            }
        }

        myScanner.close();
    }

    private static void printButtonSpec(Object selectMode) {
        System.out.println(" === 리모콘 버튼 명세 ===");
        System.out.println("POWER = \"pow\"");
        if (selectMode instanceof TV) {
            System.out.println("CH_UP = \"ch_up\"");
            System.out.println("CH_DOWN = \"ch_down\"");
            System.out.println("VOLUME_UP = \"vol_up\"");
            System.out.println("VOLUME_DOWN = \"vol_down\"");
            System.out.println("CONTRAST_UP = \"con_up\"");
            System.out.println("CONTRAST_DOWN = \"con_down\"");
            System.out.println("LIGHT_UP = \"li_up\"");
            System.out.println("LIGHT_DOWN = \"li_down\"");
        } else if (selectMode instanceof Aircon) {
            System.out.println("SPEED_UP = \"spd_up\"");
            System.out.println("SPEED_DOWN = \"spd_down\"");
            System.out.println("DEGREE_UP = \"deg_up\"");
            System.out.println("DEGREE_DOWN = \"deg_down\"");
            System.out.println("VECTOR_UP = \"vec_up\"");
            System.out.println("VECTOR_DOWN = \"vec_down\"");
        }
        System.out.println("=== 시뮬레이션 종료 ===");
        System.out.println("\"exit\"");
        System.out.println(" =================== ");
    }
}
