package w2_13_advancedsimulator;

public class MultiRemocon {

    public void btnPress(Object device, String btnInput) {
        if (device instanceof TV) {
            TVInput((TV) device, btnInput);
        } else if (device instanceof Aircon) {
            AirconInput((Aircon) device, btnInput);
        } else {
            System.out.println("지원되지 않는 기기입니다.");
        }
    }

    private void TVInput(TV tv, String btnInput) {

            TVButton button = TVButton.fromCommand(btnInput);
            switch (button) {
                case POWER :
                    tv.powerToggle();
                    break;
                case CH_UP :
                    tv.channelUp();
                    break;
                case CH_DOWN :
                    tv.channelDown();
                    break;
                case VOLUME_UP :
                    tv.volumeUp();
                    break;
                case VOLUME_DOWN :
                    tv.volumeDown();
                    break;
                case CONTRAST_UP :
                    tv.contrastUp();
                    break;
                case CONTRAST_DOWN :
                    tv.contrastDown();
                    break;
                case LIGHT_UP :
                    tv.lightUp();
                    break;
                case LIGHT_DOWN :
                    tv.lightDown();
                    break;
                default :
                    System.out.println("지원되지 않는 TV 버튼입니다.");
            }

    }

    private void AirconInput(Aircon aircon, String btnInput) {

            ACButton button = ACButton.fromCommand(btnInput);
            switch (button) {
                case POWER :
                    aircon.powerToggle();
                    break;
                case SPEED_UP :
                    aircon.speedUp();
                    break;
                case SPEED_DOWN :
                    aircon.speedDown();
                    break;
                case DEGREE_UP :
                    aircon.degreeUp();
                    break;
                case DEGREE_DOWN :
                    aircon.degreeDown();
                    break;
                case VECTOR_UP :
                    aircon.vectorUp();
                    break;
                case VECTOR_DOWN :
                    aircon.vectorDown();
                    break;
                default :
                    System.out.println("지원되지 않는 에어컨 버튼입니다.");
            }

    }
}
