package w2_13_advancedsimulator;

public enum ACButton {
    POWER("pow"),
    SPEED_UP("spd_up"),
    SPEED_DOWN("spd_down"),
    DEGREE_UP("deg_up"),
    DEGREE_DOWN("deg_down"),
    VECTOR_UP("vec_up"),
    VECTOR_DOWN("vec_down");

    private final String command;

    ACButton(String command) {
        this.command = command;
    }

    public String getCommand() {
        return command;
    }

    public static ACButton fromCommand(String command) {
        for (ACButton button : values()) {
            if (button.getCommand().equals(command)) {
                return button;
            }
        }
        throw new IllegalArgumentException("알 수 없는 에어컨 버튼 입력입니다: " + command);
    }
}
